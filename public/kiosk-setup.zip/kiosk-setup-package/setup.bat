@echo off
title Kiosk Installer
color 0A

echo =====================================
echo        KIOSK INSTALLER
echo =====================================
echo.

:: Check ADB
where adb >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] ADB not found.
    echo Please re-run the installer.
    pause
    exit /b
)

:: Check device connection
echo Checking device connection...
adb get-state >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] No device detected.
    echo Please:
    echo - Connect tablet via USB
    echo - Enable USB Debugging
    echo - Allow permission on device
    pause
    exit /b
)

echo [OK] Device connected.
echo.

:: Install APK
echo Installing application...
adb install -r app-release.apk >nul

if %errorlevel% neq 0 (
    echo [ERROR] Failed to install APK.
    echo Possible reasons:
    echo - App already installed with different signature
    echo - Storage issue
    pause
    exit /b
)

echo [OK] App installed successfully.
echo.

:: Set Device Owner
echo Setting Device Owner...
adb shell dpm set-device-owner com.kiosk.app/.core.admin.MyDeviceAdminReceiver >nul 2>nul

if %errorlevel% neq 0 (
    echo [ERROR] Failed to set Device Owner.
    echo IMPORTANT:
    echo - Device must be factory reset
    echo - No Google account must be added
    echo - No other apps installed
    pause
    exit /b
)

echo [OK] Device Owner set successfully!
echo.

:: Launch app (optional)
echo Launching kiosk app...
adb shell monkey -p com.kiosk.app -c android.intent.category.LAUNCHER 1 >nul

echo.
echo =====================================
echo        SETUP COMPLETE!
echo =====================================
echo Your device is now ready.

pause