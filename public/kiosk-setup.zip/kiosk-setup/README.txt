KIOSK SETUP GUIDE

1. Factory reset the tablet

2. Turn on the device

3. Enable Developer Mode:
   - Go to Settings → About
   - Tap "Build Number" 7 times

4. Enable USB Debugging:
   - Settings → Developer Options → USB Debugging ON

5. Connect the tablet to your computer via USB

6. Open this folder

7. Run:
   - setup.bat (Windows)
   - OR setup.sh (Mac)

8. Allow USB debugging on the tablet if prompted

DONE!