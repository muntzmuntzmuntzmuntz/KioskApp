@echo off
echo ===============================
echo KIOSK SETUP
echo ===============================

echo Checking device...
platform-tools\adb devices

echo.
echo Installing app...
platform-tools\adb install -r app-release.apk

echo.
echo Setting Device Owner...
platform-tools\adb shell dpm set-device-owner com.kiosk.app/.core.admin.MyDeviceAdminReceiver

echo.
echo ===============================
echo DONE!
echo ===============================
pause